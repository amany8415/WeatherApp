﻿namespace WeatherApp.Configuration
{
    public class Values
    {
        public const string OPEN_WATHER_APP_ID = "794e1aa4167cc569f119a90711ae8016";
    }
}
