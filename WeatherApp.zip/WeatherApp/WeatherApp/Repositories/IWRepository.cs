﻿using WeatherApp.OpenWeatherMap_Model;

namespace WeatherApp.Repositories
{
    public interface IWRepository
    {
        WeatherResponse GetForecast(string city);
    }
}
