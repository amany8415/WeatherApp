﻿using Microsoft.AspNetCore.Mvc;
using WeatherApp.Models;
using WeatherApp.OpenWeatherMap_Model;
using WeatherApp.Repositories;

namespace WeatherApp.Controllers
{
    public class WeatherController : Controller
    {
        private readonly IWRepository _WRepository;
        public WeatherController(IWRepository wRepository)
        {
            _WRepository = wRepository;
        }

        [HttpGet]
        public IActionResult SearchByCity()
        {
            var viewModel = new SearchByCity(); 
            return View(viewModel);
        }
        [HttpPost]
        public IActionResult SearchByCity(SearchByCity model)
        {
            if (ModelState.IsValid)
            {
                return RedirectToAction("City", "Weather", new { City = model.CityName });
            }
            return View(model);
        }
        [HttpGet]
        public IActionResult City(string city)
        {
            WeatherResponse weatherRepose = _WRepository.GetForecast(city);
            City viewModel = new City();

            if(weatherRepose != null)
            {
                viewModel.Name = weatherRepose.Name;
                viewModel.Temperature = weatherRepose.Main.Temp;
                viewModel.Humidity = weatherRepose.Main.Humidity;
                viewModel.Pressure = weatherRepose.Main.Pressure;
                viewModel.Weather = weatherRepose.Weather[0].Main;
                viewModel.Wind = weatherRepose.Wind.Speed;
            }
            return View(viewModel);
        }
    }
}
