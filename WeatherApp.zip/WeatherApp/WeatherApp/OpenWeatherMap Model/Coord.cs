﻿namespace WeatherApp.OpenWeatherMap_Model
{
    public class Coord
    {
        public float Lon { get; set; }
        public float Lat { get; set; }
    }
}
