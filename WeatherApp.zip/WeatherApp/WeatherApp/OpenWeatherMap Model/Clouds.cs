﻿namespace WeatherApp.OpenWeatherMap_Model
{
    public class Clouds
    {
        public int All { get; set; }
    }
}
