﻿namespace WeatherApp.OpenWeatherMap_Model
{
    public class Wind
    {
        public float Speed { get; set; }
        public int Deg { get; set; }
    }
}
