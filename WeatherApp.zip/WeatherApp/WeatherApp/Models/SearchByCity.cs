﻿using System.ComponentModel.DataAnnotations;

namespace WeatherApp.Models
{
    public class SearchByCity
    {
        [Required(ErrorMessage = " City Name is Empty !!!")]
        [Display (Name ="City Name")]
        [StringLength(30,MinimumLength = 2, ErrorMessage ="Invalid Input, Length Must Be Between 2 to 30 Characters")]
        public string CityName { get; set; } 
    }
}
